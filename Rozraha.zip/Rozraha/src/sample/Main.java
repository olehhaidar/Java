package sample;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.*;
import java.io.*;
import java.util.*;
import java.util.ArrayList;
import static java.lang.Integer.parseInt;
import javafx.scene.layout.FlowPane;
import javafx.scene.control.Label;
import javafx.scene.control.ComboBox;
import javafx.collections.ObservableList;
import javafx.collections.FXCollections;



public class Main extends Application{

    static ArrayList<Car> arrayList = new ArrayList<Car>();

    public static void main(String[] args) {


        try{
            FileReader fr1 = new FileReader("/Users/olehhaidar/IdeaProjects/Rozraha/src/sample/file1");
            FileReader fr2 = new FileReader("/Users/olehhaidar/IdeaProjects/Rozraha/src/sample/file2");
            FileReader fr3 = new FileReader("/Users/olehhaidar/IdeaProjects/Rozraha/src/sample/file3");
            BufferedReader br1 = new BufferedReader(fr1);
            BufferedReader br2 = new BufferedReader(fr2);
            BufferedReader br3 = new BufferedReader(fr3);


            String s = "";

            while ((s = br1.readLine()) != null) {
                String[] temp = s.split(" ");
                String md = temp[0];
                int sp = parseInt(temp[1]);
                int pr = parseInt(temp[2]);
                Car car = new Car(sp, pr, md);
                arrayList.add(car);

            }

            while ((s = br2.readLine()) != null) {
                String[] temp = s.split(" ");
                String md = temp[0];
                int sp = parseInt(temp[1]);
                int pr = parseInt(temp[2]);
                Car car = new Car(sp, pr, md);
                arrayList.add(car);
            }

            while ((s = br3.readLine()) != null) {
                String[] temp = s.split(" ");
                String md = temp[0];
                int sp = parseInt(temp[1]);
                int pr = parseInt(temp[2]);
                Car car = new Car(sp, pr, md);
                arrayList.add(car);
            }
            br1.close();
            br2.close();
            br3.close();

        }catch(IOException e) {}
        
        launch(args);
    }


     static void files(){
        try {
            PrintWriter pw1 = new PrintWriter("/Users/olehhaidar/IdeaProjects/Rozraha/src/sample/fileRes1");
            PrintWriter pw2 = new PrintWriter("/Users/olehhaidar/IdeaProjects/Rozraha/src/sample/fileRes2");
            PrintWriter pw3 = new PrintWriter("/Users/olehhaidar/IdeaProjects/Rozraha/src/sample/fileRes3");

            for (Car c : arrayList) {
                String tempCar = c.toString();
                if (c.price <= 4500) {
                    pw1.write(tempCar + "\n");
                } else if (c.price > 4501 && c.price <= 8500) {
                    pw2.write(tempCar + "\n");
                } else if (c.price > 8500) {
                    pw3.write(tempCar + "\n");
                }
            }

            pw1.flush();
            pw1.close();
            pw2.flush();
            pw2.close();
            pw3.flush();
            pw3.close();

        }catch(IOException ie) {}
    }
    public void start(Stage stage) {

        ObservableList<String> langs = FXCollections.observableArrayList("Method1(Model,Price,Speed)", "Method2(Price,Model,Speed)", "Method3(Speed,Price,Model)");
        ComboBox<String> ComboBox = new ComboBox<>(langs);
        ComboBox.setValue("Method1(Model,Price,Speed)");
        stage.setTitle("Sorting Cars");
        Label lb = new Label();
        Button bt = new Button("SORT");
        ComboBox.setOnAction(event -> lb.setText(ComboBox.getValue()));
        FlowPane root = new FlowPane();
        Scene scene = new Scene(root, 300,  100);

        bt.setOnAction(new EventHandler<ActionEvent>() {
            public void handle(ActionEvent ae) {
                String value = ComboBox.getValue();

                switch (value){
                    case "Method1(Model,Price,Speed)" :
                        Collections.sort(arrayList, new СomparatorByMethod1());
                        break;
                    case "Method2(Price,Model,Speed)" :
                        Collections.sort(arrayList, new СomparatorByMethod2());
                        break;
                    case "Method3(Speed,Price,Model)" :
                        Collections.sort(arrayList, new СomparatorByMethod3());
                        break;
                }
                files();
            }
        });

        stage.setScene(scene);
        root.getChildren().addAll(ComboBox,bt);
        stage.show();
    }
}
