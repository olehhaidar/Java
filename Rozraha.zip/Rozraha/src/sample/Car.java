package sample;
import java.util.*;
public class Car {

    int speed, price;
    String model;

    public Car(int speed, int price, String model) {
        this.speed = speed;
        this.price = price;
        this.model = model;
    }
    public String toString() {
        String temp = model + " " + Integer.toString(speed) + " " + Integer.toString(price);
        return temp;
    }
}
class СomparatorByMethod1 implements Comparator {
    public int compare(Object o1,Object o2){
        int delta = ((Car)o1).model.compareTo(((Car)o2).model);
        if(delta != 0) {
            return delta;
        }
        delta = ((Car)o2).price - (((Car)o1).price);
        if(delta != 0) {
            return delta;
        }
        delta = ((Car)o2).speed - ((Car)o1).speed;
        return delta;

    }
}
class СomparatorByMethod2 implements Comparator {
    public int compare(Object o1,Object o2){
        int delta = ((Car)o2).price - (((Car)o1).price);
        if(delta != 0) {
            return delta;
        }
        delta = ((Car)o1).model.compareTo(((Car)o2).model);
        if(delta != 0) {
            return delta;
        }
        delta = ((Car)o2).speed - ((Car)o1).speed;
        return delta;
    }
}

class СomparatorByMethod3 implements Comparator {
    public int compare(Object o1,Object o2){
        int delta = ((Car)o2).speed - ((Car)o1).speed;
        if(delta != 0) {
            return delta;
        }
        delta = ((Car)o2).price - (((Car)o1).price);
        if(delta != 0) {
            return delta;
        }
        delta = ((Car)o1).model.compareTo(((Car)o2).model);
        return delta;

    }
}


